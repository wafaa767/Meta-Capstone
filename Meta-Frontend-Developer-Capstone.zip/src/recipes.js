const recipes = [
    { 
      id: 1,
      title: "shrimp and a citrus beurre",
      price: 15.10,
      image: "https://wehco.media.clients.ellingtoncms.com/imports/adg/photos/198876670_WALT-IMG_0752_t800.jpg",
      description:
        "Three shrimp and a citrus beurre blanc garnish a salmon dish (with a side of asparagus and cheese grits—really)",
    },
    {
      id: 2,
      title: "Chicken Salad Croissant",
      price: 5.99,
      image: "https://www.tasteofhome.com/wp-content/uploads/2018/01/exps23698_TH1194743D8A.jpg?fit=700,1024",
      description:
        "Chicken Salad Croissant Sandwiches are filled with flavorful chicken salad stuffed between buttery, soft croissants.",
    },
    {
      id: 3,
      title: "Natural juices",
      price:12,
      image: "https://americanpregnancy.org/wp-content/uploads/2017/01/smoothies-scaled.jpg",
      description:
        "100% fruit juice, it’s basically liquid that has been pressed, squeezed or otherwise extracted from fruit.",
    },
  
  ];
  
  export default recipes;
  
  